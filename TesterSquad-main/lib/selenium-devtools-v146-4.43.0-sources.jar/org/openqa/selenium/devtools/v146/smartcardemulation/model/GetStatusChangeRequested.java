package org.openqa.selenium.devtools.v146.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardGetStatusChange| is called. Timeout is specified in milliseconds.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga33247d5d1257d59e55647c3bb717db24
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardgetstatuschangea
 */
public class GetStatusChangeRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer contextId;

    private final java.util.List<org.openqa.selenium.devtools.v146.smartcardemulation.model.ReaderStateIn> readerStates;

    private final java.util.Optional<java.lang.Integer> timeout;

    public GetStatusChangeRequested(java.lang.String requestId, java.lang.Integer contextId, java.util.List<org.openqa.selenium.devtools.v146.smartcardemulation.model.ReaderStateIn> readerStates, java.util.Optional<java.lang.Integer> timeout) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.contextId = java.util.Objects.requireNonNull(contextId, "contextId is required");
        this.readerStates = java.util.Objects.requireNonNull(readerStates, "readerStates is required");
        this.timeout = timeout;
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getContextId() {
        return contextId;
    }

    public java.util.List<org.openqa.selenium.devtools.v146.smartcardemulation.model.ReaderStateIn> getReaderStates() {
        return readerStates;
    }

    /**
     * in milliseconds, if absent, it means "infinite"
     */
    public java.util.Optional<java.lang.Integer> getTimeout() {
        return timeout;
    }

    private static GetStatusChangeRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer contextId = 0;
        java.util.List<org.openqa.selenium.devtools.v146.smartcardemulation.model.ReaderStateIn> readerStates = null;
        java.util.Optional<java.lang.Integer> timeout = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "contextId":
                    contextId = input.nextNumber().intValue();
                    break;
                case "readerStates":
                    readerStates = input.readArray(org.openqa.selenium.devtools.v146.smartcardemulation.model.ReaderStateIn.class);
                    break;
                case "timeout":
                    timeout = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new GetStatusChangeRequested(requestId, contextId, readerStates, timeout);
    }
}

package org.openqa.selenium.devtools.v146.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardDisconnect| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga4be198045c73ec0deb79e66c0ca1738a
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scarddisconnect
 */
public class DisconnectRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    private final org.openqa.selenium.devtools.v146.smartcardemulation.model.Disposition disposition;

    public DisconnectRequested(java.lang.String requestId, java.lang.Integer handle, org.openqa.selenium.devtools.v146.smartcardemulation.model.Disposition disposition) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
        this.disposition = java.util.Objects.requireNonNull(disposition, "disposition is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    public org.openqa.selenium.devtools.v146.smartcardemulation.model.Disposition getDisposition() {
        return disposition;
    }

    private static DisconnectRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        org.openqa.selenium.devtools.v146.smartcardemulation.model.Disposition disposition = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                case "disposition":
                    disposition = input.read(org.openqa.selenium.devtools.v146.smartcardemulation.model.Disposition.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DisconnectRequested(requestId, handle, disposition);
    }
}

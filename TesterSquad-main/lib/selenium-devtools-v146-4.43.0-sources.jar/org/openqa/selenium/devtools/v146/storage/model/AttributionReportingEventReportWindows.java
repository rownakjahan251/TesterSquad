package org.openqa.selenium.devtools.v146.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingEventReportWindows {

    private final java.lang.Integer start;

    private final java.util.List<java.lang.Integer> ends;

    public AttributionReportingEventReportWindows(java.lang.Integer start, java.util.List<java.lang.Integer> ends) {
        this.start = java.util.Objects.requireNonNull(start, "start is required");
        this.ends = java.util.Objects.requireNonNull(ends, "ends is required");
    }

    /**
     * duration in seconds
     */
    public java.lang.Integer getStart() {
        return start;
    }

    /**
     * duration in seconds
     */
    public java.util.List<java.lang.Integer> getEnds() {
        return ends;
    }

    private static AttributionReportingEventReportWindows fromJson(JsonInput input) {
        java.lang.Integer start = 0;
        java.util.List<java.lang.Integer> ends = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "start":
                    start = input.nextNumber().intValue();
                    break;
                case "ends":
                    ends = input.readArray(java.lang.Integer.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingEventReportWindows(start, ends);
    }
}

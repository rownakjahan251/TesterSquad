package org.openqa.selenium.devtools.v146.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingAggregatableValueEntry {

    private final java.util.List<org.openqa.selenium.devtools.v146.storage.model.AttributionReportingAggregatableValueDictEntry> values;

    private final org.openqa.selenium.devtools.v146.storage.model.AttributionReportingFilterPair filters;

    public AttributionReportingAggregatableValueEntry(java.util.List<org.openqa.selenium.devtools.v146.storage.model.AttributionReportingAggregatableValueDictEntry> values, org.openqa.selenium.devtools.v146.storage.model.AttributionReportingFilterPair filters) {
        this.values = java.util.Objects.requireNonNull(values, "values is required");
        this.filters = java.util.Objects.requireNonNull(filters, "filters is required");
    }

    public java.util.List<org.openqa.selenium.devtools.v146.storage.model.AttributionReportingAggregatableValueDictEntry> getValues() {
        return values;
    }

    public org.openqa.selenium.devtools.v146.storage.model.AttributionReportingFilterPair getFilters() {
        return filters;
    }

    private static AttributionReportingAggregatableValueEntry fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v146.storage.model.AttributionReportingAggregatableValueDictEntry> values = null;
        org.openqa.selenium.devtools.v146.storage.model.AttributionReportingFilterPair filters = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "values":
                    values = input.readArray(org.openqa.selenium.devtools.v146.storage.model.AttributionReportingAggregatableValueDictEntry.class);
                    break;
                case "filters":
                    filters = input.read(org.openqa.selenium.devtools.v146.storage.model.AttributionReportingFilterPair.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingAggregatableValueEntry(values, filters);
    }
}

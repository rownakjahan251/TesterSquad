package org.openqa.selenium.devtools.v146.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Indicates the PC/SC error code.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__ErrorCodes.html
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/secauthn/authentication-return-values
 */
public enum ResultCode {

    SUCCESS("success"),
    REMOVED_CARD("removed-card"),
    RESET_CARD("reset-card"),
    UNPOWERED_CARD("unpowered-card"),
    UNRESPONSIVE_CARD("unresponsive-card"),
    UNSUPPORTED_CARD("unsupported-card"),
    READER_UNAVAILABLE("reader-unavailable"),
    SHARING_VIOLATION("sharing-violation"),
    NOT_TRANSACTED("not-transacted"),
    NO_SMARTCARD("no-smartcard"),
    PROTO_MISMATCH("proto-mismatch"),
    SYSTEM_CANCELLED("system-cancelled"),
    NOT_READY("not-ready"),
    CANCELLED("cancelled"),
    INSUFFICIENT_BUFFER("insufficient-buffer"),
    INVALID_HANDLE("invalid-handle"),
    INVALID_PARAMETER("invalid-parameter"),
    INVALID_VALUE("invalid-value"),
    NO_MEMORY("no-memory"),
    TIMEOUT("timeout"),
    UNKNOWN_READER("unknown-reader"),
    UNSUPPORTED_FEATURE("unsupported-feature"),
    NO_READERS_AVAILABLE("no-readers-available"),
    SERVICE_STOPPED("service-stopped"),
    NO_SERVICE("no-service"),
    COMM_ERROR("comm-error"),
    INTERNAL_ERROR("internal-error"),
    SERVER_TOO_BUSY("server-too-busy"),
    UNEXPECTED("unexpected"),
    SHUTDOWN("shutdown"),
    UNKNOWN_CARD("unknown-card"),
    UNKNOWN("unknown");

    private String value;

    ResultCode(String value) {
        this.value = value;
    }

    public static ResultCode fromString(String s) {
        return java.util.Arrays.stream(ResultCode.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within ResultCode "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static ResultCode fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}

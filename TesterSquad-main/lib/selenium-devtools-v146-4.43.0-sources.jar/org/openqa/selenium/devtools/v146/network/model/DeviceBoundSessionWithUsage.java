package org.openqa.selenium.devtools.v146.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * How a device bound session was used during a request.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionWithUsage {

    public enum Usage {

        NOTINSCOPE("NotInScope"),
        INSCOPEREFRESHNOTYETNEEDED("InScopeRefreshNotYetNeeded"),
        INSCOPEREFRESHNOTALLOWED("InScopeRefreshNotAllowed"),
        PROACTIVEREFRESHNOTPOSSIBLE("ProactiveRefreshNotPossible"),
        PROACTIVEREFRESHATTEMPTED("ProactiveRefreshAttempted"),
        DEFERRED("Deferred");

        private String value;

        Usage(String value) {
            this.value = value;
        }

        public static Usage fromString(String s) {
            return java.util.Arrays.stream(Usage.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within Usage "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static Usage fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    private final org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey sessionKey;

    private final Usage usage;

    public DeviceBoundSessionWithUsage(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey sessionKey, Usage usage) {
        this.sessionKey = java.util.Objects.requireNonNull(sessionKey, "sessionKey is required");
        this.usage = java.util.Objects.requireNonNull(usage, "usage is required");
    }

    /**
     * The key for the session.
     */
    public org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey getSessionKey() {
        return sessionKey;
    }

    /**
     * How the session was used (or not used).
     */
    public Usage getUsage() {
        return usage;
    }

    private static DeviceBoundSessionWithUsage fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey sessionKey = null;
        Usage usage = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "sessionKey":
                    sessionKey = input.read(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey.class);
                    break;
                case "usage":
                    usage = Usage.fromString(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionWithUsage(sessionKey, usage);
    }
}

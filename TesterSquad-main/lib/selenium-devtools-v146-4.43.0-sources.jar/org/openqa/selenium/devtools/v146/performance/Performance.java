package org.openqa.selenium.devtools.v146.performance;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

public class Performance {

    /**
     * Disable collecting and reporting metrics.
     */
    public static Command<Void> disable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Performance.disable", Map.copyOf(params));
    }

    public enum EnableTimeDomain {

        TIMETICKS("timeTicks"), THREADTICKS("threadTicks");

        private String value;

        EnableTimeDomain(String value) {
            this.value = value;
        }

        public static EnableTimeDomain fromString(String s) {
            return java.util.Arrays.stream(EnableTimeDomain.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within EnableTimeDomain "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static EnableTimeDomain fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    /**
     * Enable collecting and reporting metrics.
     */
    public static Command<Void> enable(java.util.Optional<EnableTimeDomain> timeDomain) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        timeDomain.ifPresent(p -> params.put("timeDomain", p));
        return new Command<>("Performance.enable", Map.copyOf(params));
    }

    public enum SetTimeDomainTimeDomain {

        TIMETICKS("timeTicks"), THREADTICKS("threadTicks");

        private String value;

        SetTimeDomainTimeDomain(String value) {
            this.value = value;
        }

        public static SetTimeDomainTimeDomain fromString(String s) {
            return java.util.Arrays.stream(SetTimeDomainTimeDomain.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within SetTimeDomainTimeDomain "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static SetTimeDomainTimeDomain fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    /**
     * Sets time domain to use for collecting and reporting duration metrics.
     * Note that this must be called before enabling metrics collection. Calling
     * this method while metrics collection is enabled returns an error.
     */
    @Beta()
    @Deprecated()
    public static Command<Void> setTimeDomain(SetTimeDomainTimeDomain timeDomain) {
        java.util.Objects.requireNonNull(timeDomain, "timeDomain is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("timeDomain", timeDomain);
        return new Command<>("Performance.setTimeDomain", Map.copyOf(params));
    }

    /**
     * Retrieve current values of run-time metrics.
     */
    public static Command<java.util.List<org.openqa.selenium.devtools.v146.performance.model.Metric>> getMetrics() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Performance.getMetrics", Map.copyOf(params), ConverterFunctions.map("metrics", input -> input.readArray(org.openqa.selenium.devtools.v146.performance.model.Metric.class)));
    }

    public static Event<org.openqa.selenium.devtools.v146.performance.model.Metrics> metrics() {
        return new Event<>("Performance.metrics", input -> input.read(org.openqa.selenium.devtools.v146.performance.model.Metrics.class));
    }
}

package org.openqa.selenium.devtools.v146.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardTransmit| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga9a2d77242a271310269065e64633ab99
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardtransmit
 */
public class TransmitRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    private final java.lang.String data;

    private final java.util.Optional<org.openqa.selenium.devtools.v146.smartcardemulation.model.Protocol> protocol;

    public TransmitRequested(java.lang.String requestId, java.lang.Integer handle, java.lang.String data, java.util.Optional<org.openqa.selenium.devtools.v146.smartcardemulation.model.Protocol> protocol) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
        this.data = java.util.Objects.requireNonNull(data, "data is required");
        this.protocol = protocol;
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    public java.lang.String getData() {
        return data;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v146.smartcardemulation.model.Protocol> getProtocol() {
        return protocol;
    }

    private static TransmitRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        java.lang.String data = null;
        java.util.Optional<org.openqa.selenium.devtools.v146.smartcardemulation.model.Protocol> protocol = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                case "data":
                    data = input.nextString();
                    break;
                case "protocol":
                    protocol = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v146.smartcardemulation.model.Protocol.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new TransmitRequested(requestId, handle, data, protocol);
    }
}

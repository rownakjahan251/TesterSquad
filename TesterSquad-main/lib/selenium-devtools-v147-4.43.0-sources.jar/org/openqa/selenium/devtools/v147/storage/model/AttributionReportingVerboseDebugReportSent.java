package org.openqa.selenium.devtools.v147.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingVerboseDebugReportSent {

    private final java.lang.String url;

    private final java.util.Optional<java.util.List<java.util.Map<String, Object>>> body;

    private final java.util.Optional<java.lang.Integer> netError;

    private final java.util.Optional<java.lang.String> netErrorName;

    private final java.util.Optional<java.lang.Integer> httpStatusCode;

    public AttributionReportingVerboseDebugReportSent(java.lang.String url, java.util.Optional<java.util.List<java.util.Map<String, Object>>> body, java.util.Optional<java.lang.Integer> netError, java.util.Optional<java.lang.String> netErrorName, java.util.Optional<java.lang.Integer> httpStatusCode) {
        this.url = java.util.Objects.requireNonNull(url, "url is required");
        this.body = body;
        this.netError = netError;
        this.netErrorName = netErrorName;
        this.httpStatusCode = httpStatusCode;
    }

    public java.lang.String getUrl() {
        return url;
    }

    public java.util.Optional<java.util.List<java.util.Map<String, Object>>> getBody() {
        return body;
    }

    public java.util.Optional<java.lang.Integer> getNetError() {
        return netError;
    }

    public java.util.Optional<java.lang.String> getNetErrorName() {
        return netErrorName;
    }

    public java.util.Optional<java.lang.Integer> getHttpStatusCode() {
        return httpStatusCode;
    }

    private static AttributionReportingVerboseDebugReportSent fromJson(JsonInput input) {
        java.lang.String url = null;
        java.util.Optional<java.util.List<java.util.Map<String, Object>>> body = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> netError = java.util.Optional.empty();
        java.util.Optional<java.lang.String> netErrorName = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> httpStatusCode = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "url":
                    url = input.nextString();
                    break;
                case "body":
                    body = java.util.Optional.ofNullable(input.readArray(java.util.Map.class));
                    break;
                case "netError":
                    netError = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "netErrorName":
                    netErrorName = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "httpStatusCode":
                    httpStatusCode = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingVerboseDebugReportSent(url, body, netError, netErrorName, httpStatusCode);
    }
}

package org.openqa.selenium.devtools.v147.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Maps to the |SCARD_SHARE_*| values.
 */
public enum ShareMode {

    SHARED("shared"), EXCLUSIVE("exclusive"), DIRECT("direct");

    private String value;

    ShareMode(String value) {
        this.value = value;
    }

    public static ShareMode fromString(String s) {
        return java.util.Arrays.stream(ShareMode.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within ShareMode "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static ShareMode fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}

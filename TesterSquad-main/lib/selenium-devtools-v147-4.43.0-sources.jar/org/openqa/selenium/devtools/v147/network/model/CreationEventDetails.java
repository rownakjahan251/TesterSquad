package org.openqa.selenium.devtools.v147.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Session event details specific to creation.
 */
@org.openqa.selenium.Beta()
public class CreationEventDetails {

    private final org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFetchResult fetchResult;

    private final java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSession> newSession;

    private final java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFailedRequest> failedRequest;

    public CreationEventDetails(org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFetchResult fetchResult, java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSession> newSession, java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFailedRequest> failedRequest) {
        this.fetchResult = java.util.Objects.requireNonNull(fetchResult, "fetchResult is required");
        this.newSession = newSession;
        this.failedRequest = failedRequest;
    }

    /**
     * The result of the fetch attempt.
     */
    public org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFetchResult getFetchResult() {
        return fetchResult;
    }

    /**
     * The session if there was a newly created session. This is populated for
     * all successful creation events.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSession> getNewSession() {
        return newSession;
    }

    /**
     * Details about a failed device bound session network request if there was
     * one.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFailedRequest> getFailedRequest() {
        return failedRequest;
    }

    private static CreationEventDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFetchResult fetchResult = null;
        java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSession> newSession = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFailedRequest> failedRequest = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "fetchResult":
                    fetchResult = input.read(org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFetchResult.class);
                    break;
                case "newSession":
                    newSession = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v147.network.model.DeviceBoundSession.class));
                    break;
                case "failedRequest":
                    failedRequest = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v147.network.model.DeviceBoundSessionFailedRequest.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CreationEventDetails(fetchResult, newSession, failedRequest);
    }
}

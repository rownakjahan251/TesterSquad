package org.openqa.selenium.devtools.v147.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Indicates what the reader should do with the card.
 */
public enum Disposition {

    LEAVE_CARD("leave-card"), RESET_CARD("reset-card"), UNPOWER_CARD("unpower-card"), EJECT_CARD("eject-card");

    private String value;

    Disposition(String value) {
        this.value = value;
    }

    public static Disposition fromString(String s) {
        return java.util.Arrays.stream(Disposition.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within Disposition "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static Disposition fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}

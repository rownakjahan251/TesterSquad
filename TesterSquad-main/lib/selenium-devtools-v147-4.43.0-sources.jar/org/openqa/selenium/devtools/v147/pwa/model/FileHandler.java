package org.openqa.selenium.devtools.v147.pwa.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class FileHandler {

    private final java.lang.String action;

    private final java.util.List<org.openqa.selenium.devtools.v147.pwa.model.FileHandlerAccept> accepts;

    private final java.lang.String displayName;

    public FileHandler(java.lang.String action, java.util.List<org.openqa.selenium.devtools.v147.pwa.model.FileHandlerAccept> accepts, java.lang.String displayName) {
        this.action = java.util.Objects.requireNonNull(action, "action is required");
        this.accepts = java.util.Objects.requireNonNull(accepts, "accepts is required");
        this.displayName = java.util.Objects.requireNonNull(displayName, "displayName is required");
    }

    public java.lang.String getAction() {
        return action;
    }

    public java.util.List<org.openqa.selenium.devtools.v147.pwa.model.FileHandlerAccept> getAccepts() {
        return accepts;
    }

    public java.lang.String getDisplayName() {
        return displayName;
    }

    private static FileHandler fromJson(JsonInput input) {
        java.lang.String action = null;
        java.util.List<org.openqa.selenium.devtools.v147.pwa.model.FileHandlerAccept> accepts = null;
        java.lang.String displayName = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "action":
                    action = input.nextString();
                    break;
                case "accepts":
                    accepts = input.readArray(org.openqa.selenium.devtools.v147.pwa.model.FileHandlerAccept.class);
                    break;
                case "displayName":
                    displayName = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new FileHandler(action, accepts, displayName);
    }
}

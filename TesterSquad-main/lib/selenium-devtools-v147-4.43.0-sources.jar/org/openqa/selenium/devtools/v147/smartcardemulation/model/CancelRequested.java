package org.openqa.selenium.devtools.v147.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardCancel| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gaacbbc0c6d6c0cbbeb4f4debf6fbeeee6
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardcancel
 */
public class CancelRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer contextId;

    public CancelRequested(java.lang.String requestId, java.lang.Integer contextId) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.contextId = java.util.Objects.requireNonNull(contextId, "contextId is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getContextId() {
        return contextId;
    }

    private static CancelRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer contextId = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "contextId":
                    contextId = input.nextNumber().intValue();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CancelRequested(requestId, contextId);
    }
}

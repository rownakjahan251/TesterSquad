package org.openqa.selenium.devtools.v147.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardGetAttrib| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gaacfec51917255b7a25b94c5104961602
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardgetattrib
 */
public class GetAttribRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    private final java.lang.Integer attribId;

    public GetAttribRequested(java.lang.String requestId, java.lang.Integer handle, java.lang.Integer attribId) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
        this.attribId = java.util.Objects.requireNonNull(attribId, "attribId is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    public java.lang.Integer getAttribId() {
        return attribId;
    }

    private static GetAttribRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        java.lang.Integer attribId = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                case "attribId":
                    attribId = input.nextNumber().intValue();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new GetAttribRequested(requestId, handle, attribId);
    }
}

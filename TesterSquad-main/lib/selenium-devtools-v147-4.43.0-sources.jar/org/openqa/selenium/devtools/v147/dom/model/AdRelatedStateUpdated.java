package org.openqa.selenium.devtools.v147.dom.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when a node's ad related state changes.
 */
@org.openqa.selenium.Beta()
public class AdRelatedStateUpdated {

    private final org.openqa.selenium.devtools.v147.dom.model.NodeId nodeId;

    private final java.lang.Boolean isAdRelated;

    public AdRelatedStateUpdated(org.openqa.selenium.devtools.v147.dom.model.NodeId nodeId, java.lang.Boolean isAdRelated) {
        this.nodeId = java.util.Objects.requireNonNull(nodeId, "nodeId is required");
        this.isAdRelated = java.util.Objects.requireNonNull(isAdRelated, "isAdRelated is required");
    }

    /**
     * The id of the node.
     */
    public org.openqa.selenium.devtools.v147.dom.model.NodeId getNodeId() {
        return nodeId;
    }

    /**
     * If the node is ad related.
     */
    public java.lang.Boolean getIsAdRelated() {
        return isAdRelated;
    }

    private static AdRelatedStateUpdated fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v147.dom.model.NodeId nodeId = null;
        java.lang.Boolean isAdRelated = false;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "nodeId":
                    nodeId = input.read(org.openqa.selenium.devtools.v147.dom.model.NodeId.class);
                    break;
                case "isAdRelated":
                    isAdRelated = input.nextBoolean();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdRelatedStateUpdated(nodeId, isAdRelated);
    }
}

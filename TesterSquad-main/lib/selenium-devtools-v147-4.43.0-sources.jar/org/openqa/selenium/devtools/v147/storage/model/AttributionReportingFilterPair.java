package org.openqa.selenium.devtools.v147.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingFilterPair {

    private final java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> filters;

    private final java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> notFilters;

    public AttributionReportingFilterPair(java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> filters, java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> notFilters) {
        this.filters = java.util.Objects.requireNonNull(filters, "filters is required");
        this.notFilters = java.util.Objects.requireNonNull(notFilters, "notFilters is required");
    }

    public java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> getFilters() {
        return filters;
    }

    public java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> getNotFilters() {
        return notFilters;
    }

    private static AttributionReportingFilterPair fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> filters = null;
        java.util.List<org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig> notFilters = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "filters":
                    filters = input.readArray(org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig.class);
                    break;
                case "notFilters":
                    notFilters = input.readArray(org.openqa.selenium.devtools.v147.storage.model.AttributionReportingFilterConfig.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingFilterPair(filters, notFilters);
    }
}

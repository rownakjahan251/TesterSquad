package org.openqa.selenium.devtools.v145.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class UnsignedInt64AsBase10 {

    private final java.lang.String unsignedInt64AsBase10;

    public UnsignedInt64AsBase10(java.lang.String unsignedInt64AsBase10) {
        this.unsignedInt64AsBase10 = java.util.Objects.requireNonNull(unsignedInt64AsBase10, "Missing value for UnsignedInt64AsBase10");
    }

    private static UnsignedInt64AsBase10 fromJson(JsonInput input) {
        return new UnsignedInt64AsBase10(input.nextString());
    }

    public String toJson() {
        return unsignedInt64AsBase10.toString();
    }

    public String toString() {
        return unsignedInt64AsBase10.toString();
    }
}

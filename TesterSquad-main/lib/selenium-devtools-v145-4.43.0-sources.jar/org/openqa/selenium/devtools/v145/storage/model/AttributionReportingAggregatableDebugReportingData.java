package org.openqa.selenium.devtools.v145.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingAggregatableDebugReportingData {

    private final org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece;

    private final java.lang.Number value;

    private final java.util.List<java.lang.String> types;

    public AttributionReportingAggregatableDebugReportingData(org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece, java.lang.Number value, java.util.List<java.lang.String> types) {
        this.keyPiece = java.util.Objects.requireNonNull(keyPiece, "keyPiece is required");
        this.value = java.util.Objects.requireNonNull(value, "value is required");
        this.types = java.util.Objects.requireNonNull(types, "types is required");
    }

    public org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 getKeyPiece() {
        return keyPiece;
    }

    /**
     * number instead of integer because not all uint32 can be represented by
     * int
     */
    public java.lang.Number getValue() {
        return value;
    }

    public java.util.List<java.lang.String> getTypes() {
        return types;
    }

    private static AttributionReportingAggregatableDebugReportingData fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece = null;
        java.lang.Number value = 0;
        java.util.List<java.lang.String> types = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "keyPiece":
                    keyPiece = input.read(org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16.class);
                    break;
                case "value":
                    value = input.nextNumber();
                    break;
                case "types":
                    types = input.readArray(java.lang.String.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingAggregatableDebugReportingData(keyPiece, value, types);
    }
}

package org.openqa.selenium.devtools.v145.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A device bound session's inclusion rules.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionInclusionRules {

    private final java.lang.String origin;

    private final java.lang.Boolean includeSite;

    private final java.util.List<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionUrlRule> urlRules;

    public DeviceBoundSessionInclusionRules(java.lang.String origin, java.lang.Boolean includeSite, java.util.List<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionUrlRule> urlRules) {
        this.origin = java.util.Objects.requireNonNull(origin, "origin is required");
        this.includeSite = java.util.Objects.requireNonNull(includeSite, "includeSite is required");
        this.urlRules = java.util.Objects.requireNonNull(urlRules, "urlRules is required");
    }

    /**
     * See comments on `net::device_bound_sessions::SessionInclusionRules::origin_`.
     */
    public java.lang.String getOrigin() {
        return origin;
    }

    /**
     * Whether the whole site is included. See comments on
     * `net::device_bound_sessions::SessionInclusionRules::include_site_` for more
     * details; this boolean is true if that value is populated.
     */
    public java.lang.Boolean getIncludeSite() {
        return includeSite;
    }

    /**
     * See comments on `net::device_bound_sessions::SessionInclusionRules::url_rules_`.
     */
    public java.util.List<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionUrlRule> getUrlRules() {
        return urlRules;
    }

    private static DeviceBoundSessionInclusionRules fromJson(JsonInput input) {
        java.lang.String origin = null;
        java.lang.Boolean includeSite = false;
        java.util.List<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionUrlRule> urlRules = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "origin":
                    origin = input.nextString();
                    break;
                case "includeSite":
                    includeSite = input.nextBoolean();
                    break;
                case "urlRules":
                    urlRules = input.readArray(org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionUrlRule.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionInclusionRules(origin, includeSite, urlRules);
    }
}

package org.openqa.selenium.devtools.v145.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Session event details specific to refresh.
 */
@org.openqa.selenium.Beta()
public class RefreshEventDetails {

    public enum RefreshResult {

        REFRESHED("Refreshed"),
        INITIALIZEDSERVICE("InitializedService"),
        UNREACHABLE("Unreachable"),
        SERVERERROR("ServerError"),
        REFRESHQUOTAEXCEEDED("RefreshQuotaExceeded"),
        FATALERROR("FatalError"),
        SIGNINGQUOTAEXCEEDED("SigningQuotaExceeded");

        private String value;

        RefreshResult(String value) {
            this.value = value;
        }

        public static RefreshResult fromString(String s) {
            return java.util.Arrays.stream(RefreshResult.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within RefreshResult "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static RefreshResult fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    private final RefreshResult refreshResult;

    private final java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionFetchResult> fetchResult;

    private final java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSession> newSession;

    private final java.lang.Boolean wasFullyProactiveRefresh;

    public RefreshEventDetails(RefreshResult refreshResult, java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionFetchResult> fetchResult, java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSession> newSession, java.lang.Boolean wasFullyProactiveRefresh) {
        this.refreshResult = java.util.Objects.requireNonNull(refreshResult, "refreshResult is required");
        this.fetchResult = fetchResult;
        this.newSession = newSession;
        this.wasFullyProactiveRefresh = java.util.Objects.requireNonNull(wasFullyProactiveRefresh, "wasFullyProactiveRefresh is required");
    }

    /**
     * The result of a refresh.
     */
    public RefreshResult getRefreshResult() {
        return refreshResult;
    }

    /**
     * If there was a fetch attempt, the result of that.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionFetchResult> getFetchResult() {
        return fetchResult;
    }

    /**
     * The session display if there was a newly created session. This is populated
     * for any refresh event that modifies the session config.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSession> getNewSession() {
        return newSession;
    }

    /**
     * See comments on `net::device_bound_sessions::RefreshEventResult::was_fully_proactive_refresh`.
     */
    public java.lang.Boolean getWasFullyProactiveRefresh() {
        return wasFullyProactiveRefresh;
    }

    private static RefreshEventDetails fromJson(JsonInput input) {
        RefreshResult refreshResult = null;
        java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionFetchResult> fetchResult = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v145.network.model.DeviceBoundSession> newSession = java.util.Optional.empty();
        java.lang.Boolean wasFullyProactiveRefresh = false;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "refreshResult":
                    refreshResult = RefreshResult.fromString(input.nextString());
                    break;
                case "fetchResult":
                    fetchResult = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.network.model.DeviceBoundSessionFetchResult.class));
                    break;
                case "newSession":
                    newSession = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.network.model.DeviceBoundSession.class));
                    break;
                case "wasFullyProactiveRefresh":
                    wasFullyProactiveRefresh = input.nextBoolean();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new RefreshEventDetails(refreshResult, fetchResult, newSession, wasFullyProactiveRefresh);
    }
}

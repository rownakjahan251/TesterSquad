package org.openqa.selenium.devtools.v145.autofill.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class Address {

    private final java.util.List<org.openqa.selenium.devtools.v145.autofill.model.AddressField> fields;

    public Address(java.util.List<org.openqa.selenium.devtools.v145.autofill.model.AddressField> fields) {
        this.fields = java.util.Objects.requireNonNull(fields, "fields is required");
    }

    /**
     * fields and values defining an address.
     */
    public java.util.List<org.openqa.selenium.devtools.v145.autofill.model.AddressField> getFields() {
        return fields;
    }

    private static Address fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v145.autofill.model.AddressField> fields = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "fields":
                    fields = input.readArray(org.openqa.selenium.devtools.v145.autofill.model.AddressField.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new Address(fields);
    }
}

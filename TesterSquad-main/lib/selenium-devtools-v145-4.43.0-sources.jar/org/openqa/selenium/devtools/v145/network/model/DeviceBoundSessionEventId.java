package org.openqa.selenium.devtools.v145.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A unique identifier for a device bound session event.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionEventId {

    private final java.lang.String deviceBoundSessionEventId;

    public DeviceBoundSessionEventId(java.lang.String deviceBoundSessionEventId) {
        this.deviceBoundSessionEventId = java.util.Objects.requireNonNull(deviceBoundSessionEventId, "Missing value for DeviceBoundSessionEventId");
    }

    private static DeviceBoundSessionEventId fromJson(JsonInput input) {
        return new DeviceBoundSessionEventId(input.nextString());
    }

    public String toJson() {
        return deviceBoundSessionEventId.toString();
    }

    public String toString() {
        return deviceBoundSessionEventId.toString();
    }
}

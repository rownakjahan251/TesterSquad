package org.openqa.selenium.devtools.v145.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingFilterDataEntry {

    private final java.lang.String key;

    private final java.util.List<java.lang.String> values;

    public AttributionReportingFilterDataEntry(java.lang.String key, java.util.List<java.lang.String> values) {
        this.key = java.util.Objects.requireNonNull(key, "key is required");
        this.values = java.util.Objects.requireNonNull(values, "values is required");
    }

    public java.lang.String getKey() {
        return key;
    }

    public java.util.List<java.lang.String> getValues() {
        return values;
    }

    private static AttributionReportingFilterDataEntry fromJson(JsonInput input) {
        java.lang.String key = null;
        java.util.List<java.lang.String> values = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "key":
                    key = input.nextString();
                    break;
                case "values":
                    values = input.readArray(java.lang.String.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingFilterDataEntry(key, values);
    }
}
